# AutoPreset Backend (FastAPI)

Backend untuk Custom GPT AutoPreset. Mendukung masking selektif wajah dan tubuh.

## Jalankan Lokal
```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

## Render.com Setup
- Gunakan start command:
```bash
uvicorn main:app --host 0.0.0.0 --port 10000
```
