
from fastapi import FastAPI, File, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel
from PIL import Image
import numpy as np
import uvicorn
import os
import cv2
import mediapipe as mp

app = FastAPI()
OUTPUT_DIR = "outputs"
os.makedirs(OUTPUT_DIR, exist_ok=True)

def apply_soft_skin_studio(img_np):
    img = img_np.astype(np.float32)
    img[..., 0] *= 1.05
    img[..., 1] *= 1.02
    img[..., 2] *= 0.95
    img = (img - 128) * 0.95 + 128
    return np.clip(img, 0, 255).astype(np.uint8)

def apply_teal_orange_cinematic(img_np):
    img = img_np.astype(np.float32)
    result = img.copy()
    shadow_mask = img < 110
    result[..., 0][shadow_mask[..., 0]] *= 0.9
    result[..., 1][shadow_mask[..., 1]] *= 1.05
    result[..., 2][shadow_mask[..., 2]] *= 1.15
    highlight_mask = img > 180
    result[..., 0][highlight_mask[..., 0]] *= 1.15
    result[..., 1][highlight_mask[..., 1]] *= 1.05
    result[..., 2][highlight_mask[..., 2]] *= 0.9
    result = (result - 128) * 1.1 + 128
    return np.clip(result, 0, 255).astype(np.uint8)

def get_object_mask(image_np):
    mp_face_detection = mp.solutions.face_detection
    mp_pose = mp.solutions.pose
    face_mask = np.zeros(image_np.shape[:2], dtype=np.uint8)
    full_mask = np.zeros_like(face_mask)
    image_rgb = cv2.cvtColor(image_np, cv2.COLOR_RGB2BGR)
    with mp_face_detection.FaceDetection(model_selection=1, min_detection_confidence=0.5) as face_detection:
        face_results = face_detection.process(image_rgb)
        if face_results.detections:
            for detection in face_results.detections:
                bbox = detection.location_data.relative_bounding_box
                h, w, _ = image_np.shape
                x = int(bbox.xmin * w)
                y = int(bbox.ymin * h)
                w_box = int(bbox.width * w)
                h_box = int(bbox.height * h)
                cv2.rectangle(face_mask, (x, y), (x + w_box, y + h_box), 255, -1)
    with mp_pose.Pose(static_image_mode=True) as pose:
        pose_results = pose.process(image_rgb)
        if pose_results.pose_landmarks:
            for lm in pose_results.pose_landmarks.landmark:
                cx, cy = int(lm.x * image_np.shape[1]), int(lm.y * image_np.shape[0])
                cv2.circle(full_mask, (cx, cy), 20, 255, -1)
    combined = cv2.bitwise_or(face_mask, full_mask)
    return combined

def apply_preset_with_mask(img_np, preset_func):
    face_mask = get_object_mask(img_np)
    face_mask_3ch = np.stack([face_mask] * 3, axis=-1)
    face_mask_inv = 255 - face_mask_3ch
    edited_np = preset_func(img_np)
    final = (img_np * (face_mask_3ch / 255) + edited_np * (face_mask_inv / 255)).astype(np.uint8)
    return final

PRESET_MAP = {
    "soft_skin": apply_soft_skin_studio,
    "cinematic": apply_teal_orange_cinematic
}

class PresetRequest(BaseModel):
    preset: str

@app.post("/apply_preset")
async def apply_preset(preset: str, file: UploadFile = File(...)):
    image = Image.open(file.file).convert("RGB")
    img_np = np.array(image)
    if preset not in PRESET_MAP:
        return {"error": "Preset not found"}
    edited_np = apply_preset_with_mask(img_np, PRESET_MAP[preset])
    edited_img = Image.fromarray(edited_np)
    out_path = os.path.join(OUTPUT_DIR, f"edited_{preset}.jpg")
    edited_img.save(out_path)
    return FileResponse(out_path, media_type="image/jpeg")

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
